			<li>
				<a href="index.php?hal=pendaftaran&act=view" clas="amenu">Pendaftaran</a>
			</li>
			<li>
				<a href="index.php?hal=pemeriksaan&act=view" clas="amenu">Pemeriksaan</a>
			</li>
			<li>
				<a href="index.php?hal=resep&act=view" clas="amenu">Resep</a>
			</li>
			<li>
				<a href="index.php?hal=obat&act=view" clas="amenu">Obat</a>
			</li>