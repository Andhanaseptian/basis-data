
			<li>
				<a href="index.php?hal=pegawai&act=view" clas="amenu">Pegawai</a>
			</li>
			<li>
				<a href="index.php?hal=poliklinik&act=view" clas="amenu">Poli</a>
			</li>
			<li>
				<a href="index.php?hal=dokter&act=view" clas="amenu">Dokter</a>
			</li>