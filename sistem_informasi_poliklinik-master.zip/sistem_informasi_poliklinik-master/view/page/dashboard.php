
		<div id="isi">
			<h2 class="fullwidth aligncenter">JADWAL DOKTER</h2>
			<table id="jadwal">
				<thead>
					<tr class="table-header">
						<th>Waktu</th>
						<th>Senin</th>
						<th>Selasa</th>
						<th>Rabu</th>
						<th>Kamis</th>
						<th>Jum'at</th>
						<th>Sabtu</th>
						<th>Minggu</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Pagi</td>
						<td>Muktazam Hasbi Ashidiqi</td>
						<td>Rizky Bagus</td>
						<td>Lili Arga</td>
						<td>Nabil Baktir</td>
						<td>Muhammad</td>
						<td>Bagas Haidar</td>
						<td></td>
					</tr>
					<tr>
						<td>Siang</td>
						<td>Rizky Bagus</td>
						<td>Nabil Baktir</td>
						<td>Muktazam Hasbi</td>
						<td>Lili Arga</td>
						<td>Bagas Haidar</td>
						<td>Muhammad</td>
						<td>Novian Putra</td>
					</tr>
					<tr>										
						<td>Sore</td>
						<td>Nabil Baktir</td>
						<td></td>
						<td>Lili Arga</td>
						<td></td>
						<td>Rizky Bagus</td>
						<td>Muhammad</td>
						<td>Novian Putra</td>
					</tr>
					<tr>					
						<td>Malam</td>
						<td>Nabil Baktir</td>
						<td>Muktazam Hasbi</td>
						<td>Lili Arga</td>
						<td>Bagas Haidar</td>
						<td>Rizky Bagus</td>
						<td>Muhammad</td>
						<td>Novian Putra</td>
					</tr>
				</tbody>
			</table>
			<!--<table id="jadwal">
				<thead>
					<tr class="table-header">
						<th>a</th>
						<th>b</th>
						<th>c</th>
						<th>d</th>
						<th>e</th>
						<th>f</th>
						<th>g</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><img src="images/user/user-a.svg" style="width:100px"></td>
						<td><img src="images/user/user-b.svg" style="width:100px"></td>
						<td><img src="images/user/user-c.svg" style="width:100px"></td>
						<td><img src="images/user/user-d.svg" style="width:100px"></td>
						<td><img src="images/user/user-e.svg" style="width:100px"></td>
						<td><img src="images/user/user-f.svg" style="width:100px"></td>
						<td><img src="images/user/user-g.svg" style="width:100px"></td>
					</tr>
					<tr>
						<td><img src="images/user/user-h.svg" style="width:100px"></td>
						<td><img src="images/user/user-i.svg" style="width:100px"></td>
						<td><img src="images/user/user-j.svg" style="width:100px"></td>
						<td><img src="images/user/user-k.svg" style="width:100px"></td>
						<td><img src="images/user/user-l.svg" style="width:100px"></td>
						<td><img src="images/user/user-m.svg" style="width:100px"></td>
						<td><img src="images/user/user-n.svg" style="width:100px"></td>
					</tr>
					<tr>
						<td><img src="images/user/user-o.svg" style="width:100px"></td>
						<td><img src="images/user/user-p.svg" style="width:100px"></td>
						<td><img src="images/user/user-q.svg" style="width:100px"></td>
						<td><img src="images/user/user-r.svg" style="width:100px"></td>
						<td><img src="images/user/user-s.svg" style="width:100px"></td>
						<td><img src="images/user/user-t.svg" style="width:100px"></td>
						<td><img src="images/user/user-u.svg" style="width:100px"></td>
					</tr>
					<tr>
						<td><img src="images/user/user-v.svg" style="width:100px"></td>
						<td><img src="images/user/user-w.svg" style="width:100px"></td>
						<td><img src="images/user/user-x.svg" style="width:100px"></td>
						<td><img src="images/user/user-y.svg" style="width:100px"></td>
						<td><img src="images/user/user-z.svg" style="width:100px"></td>
						<td><img src="images/user/user.svg" style="width:100px"></td>
						<td><img src="images/user/user-g.svg" style="width:100px"></td>
					</tr>
				</tbody>
			</table>-->
		</div>