<?php
	$konek = new mysqli('localhost','root','','poliklinik');
?>